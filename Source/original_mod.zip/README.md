# Heavy_Melee_Weapons
Where the magic happens.
Heavy Melee Weapons is rimworld mod that seeks to provide an assortment of powerful melee weapons.
Each weapon serves a unique purpose and deals great damage to make up for the disadvantage of being melee.

This version of the mod is designed to co-exist with Vanilla Rimworld, the  Royalty expansion, and the Vanilla Expanded Mod series.

[![ko-fi](https://ko-fi.com/img/githubbutton_sm.svg)](https://ko-fi.com/M4M44PFV1)

[CC BY-NC-ND 4.0](https://creativecommons.org/licenses/by-nc/4.0/)
